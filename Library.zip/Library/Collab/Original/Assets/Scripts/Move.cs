﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move : MonoBehaviour {

    private Rigidbody2D rb2d;
    public float speed;
    private Transform t;
    public float jumpin;

    private void Start()
    {
        rb2d = GetComponent<Rigidbody2D>();
        t = GetComponent<Transform>();
        rb2d.freezeRotation = true;
    }

    public void FixedUpdate()
    {
        float walk = Input.GetAxis("Horizontal");
    Vector2 v2 = new Vector2(walk, 0);
        

        rb2d.AddForce(v2 * speed);
    }

    public void LateUpdate()
    {
        bool jump = false;
        Vector2 up = new Vector2(0, jumpin);

         if (jump = Input.GetKeyDown(KeyCode.Space));
        {
            t.Translate(up);
        }
    }
}