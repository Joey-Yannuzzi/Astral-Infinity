﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ele : MonoBehaviour {

    public Rigidbody2D rb2d;
    public Move move;

	void Start () {
		
	}

    public void Update()
    {
        if (move.godown == true)
        {
            Vector2 move = new Vector2(0, -1);
        }
    }
}
