﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NPC : MonoBehaviour {

    public GameObject npc;
    private Rigidbody2D rb2d;
    public Move move;
    public bool reset;
    public float speed;
    private Transform t;
    private float x;
    private float y;
    public Shoot shoot;
    private int health;
    public bool moveable;
    public bool vertical;
    public string tag;
    Vector2 moved;
    Vector2 right = new Vector2 (2, 0);
    Vector2 left = new Vector2(-1, 0);
    private float xx;
        private float yy;
    public Transform main;
    public GameObject portal;

    private void Start()
    {
        portal.SetActive(false);
        rb2d = GetComponent<Rigidbody2D>();
        reset = false;
        t = GetComponent<Transform>();
        x = t.position.x;
        y = t.position.y;
        xx = -1;
        yy = 0;

        if (npc.CompareTag("Boss"))
        {
            health = shoot.bosss;
            tag = npc.tag;
        }

        else if (npc.CompareTag("Enemy"))
        {
            health = shoot.enemys;
            tag = npc.tag;
        }

        else if (npc.CompareTag("M-Boss"))
        {
            health = shoot.mbosss;
            tag = npc.tag;
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {

        if (other.gameObject.CompareTag("MainCamera"))
        {
            reset = true;
        }
    }

    private void FixedUpdate()
    {
        if (moveable == true)
        {
            if (vertical == false)
            {
                if (reset == true)
                {
                        moved = new Vector2(xx, yy);
                        rb2d.AddForce(moved * speed);
                }
            }

            else
            {
                xx = 0;
                yy = 1;
                moved = new Vector2(xx, yy);
                rb2d.AddForce(moved * speed);
            }
        }
    }

    public void Update()
    {
        if (move.pos == true)
        {
            npc.SetActive(false);
            move.pos = false;
            //reset = true;

            Vector2 position = new Vector2(x, y);
            t.position = position;
            reset = false;
            npc.SetActive(true);

            if (npc.CompareTag("Boss"))
            {
                health = shoot.bosss;
            }

            else if (npc.CompareTag("Enemy"))
            {
                health = shoot.enemys;
            }

            else if (npc.CompareTag("M-Boss"))
            {
                health = shoot.mbosss;
            }
        }
    }

    public void Enemyhealth(GameObject other)
    {
        if (other.gameObject.Equals(npc))
        {
            health = health - 1;

            if (health < 1)
            {
                npc.SetActive(false);
            }
        }
    }

    public void Bosshealth(GameObject other)
    {
        if (other.gameObject.Equals(npc))
        {
            health = health - 1;

            if (health < 1)
            {
                npc.SetActive(false);
                portal.SetActive(true);
            }
        }
    }

    public void mbosshealth(GameObject other)
    {
        if (other.gameObject.Equals(npc))
        {
            health = health - 1;

            if (health < 1)
            {
                npc.SetActive(false);
            }
        }
    }
}
