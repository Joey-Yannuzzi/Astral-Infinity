﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Move : MonoBehaviour {

    private Rigidbody2D rb2d;
    public float speed;
    private Transform t;
    public float jumpin;
    private Animator main;
    public bool right;
    private float health;
    public GameObject heart;
    public GameObject heart1;
    public GameObject heart2;
    public float knock;
    public GameObject player;
    public Text go;
    private int lives;
    public GameObject camera;
    public Text lt;
    private float y;
    public GameObject bullet;
    public Shoot shoot;
    private float walk;
    public bool pos;
    private float x;
    public bool godown;
    public bool world;

    private void Start()
    {
        rb2d = GetComponent<Rigidbody2D>();
        t = GetComponent<Transform>();
        rb2d.freezeRotation = true;
        main = GetComponent<Animator>();
        right = true;
        health = 3;
        go.text = "";
        heart.SetActive(true);
        heart1.SetActive(true);
        heart2.SetActive(true);
        lives = 5;
        lt.text = "Lives: 5";
        y = t.position.y;
        x = t.position.x;
        godown = false;
        lives_check();
        world = false;
    }

    public void FixedUpdate()
    {
        if (shoot.fire == false)
        {
            walk = Input.GetAxis("Horizontal");
            Vector2 v2 = new Vector2(walk, 0);


            rb2d.AddForce(v2 * speed);

            main.SetFloat("Speed", Mathf.Abs(rb2d.velocity.x));

            if (walk < 0 && right)
            {
                turn();
            }

            else if (walk > 0 && !right)
            {
                turn();
            }
        }

        else
        {
            float revwalk = walk * -1;
            Vector2 v2 = new Vector2(revwalk, 0);
            rb2d.AddForce(v2);
        }
    }

    public void damage()
    {
        if (health == 3)
        {
            heart.SetActive(true);
            heart1.SetActive(true);
            heart2.SetActive(true);
        }
        else if (health == 2)
        {
            heart.SetActive(true);
            heart1.SetActive(true);
            heart2.SetActive(false);
        }

        else if (health == 1)
        {
            heart.SetActive(true);
            heart1.SetActive(false);
            heart2.SetActive(false);
        }

        else if (health == 0)
        {
            heart.SetActive(false);
            heart1.SetActive(false);
            heart2.SetActive(false);
            player.SetActive(false);
            lives = lives - 1;
            lt.text = "Lives: " + lives;
            lives_check();
        }

        else if (health < 0 || health > 3 || lives < 0 || lives > 5)
        {
            player.SetActive(false);
            go.text = "FATAL ERROR";
        }
    }

    void turn()
        {
        right = !right;
        Vector2 flip = rb2d.transform.localScale;
        flip.x *= -1;
        rb2d.transform.localScale = flip;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Enemy"))
        {
            Vector2 push = new Vector2(knock, 0);
            health = health - 1;
            player.SetActive(false);
            t.Translate(push);
            player.SetActive(true);
            damage();
        }

        else if (other.gameObject.CompareTag("Boss"))
        {
            Vector2 push = new Vector2(knock, 0);
            health = health - 1;
            player.SetActive(false);
            t.Translate(push);
            player.SetActive(true);
            damage();
        }

        else if (other.gameObject.CompareTag("M-Boss"))
        {
            Vector2 push = new Vector2(knock, 0);
            health = health - 1;
            player.SetActive(false);
            t.Translate(push);
            player.SetActive(true);
            damage();
        }

        else if (other.gameObject.CompareTag("platform"))
        {
            health = 0;
            damage();
        }

        else if (other.gameObject.CompareTag("e"))
        {
            godown = true;
        }

        else if (other.gameObject.CompareTag("portal"))
        {
            player.SetActive(false);
            world = true;
        }

        else
        {

        }
    }

    void lives_check()
    {
        if (lives <= 0)
        {
            player.SetActive(false);
            go.color = Color.red;
            go.text = "GAME OVER";
        }

        else
        {
            pos = true;
            health = 3;
            heart.SetActive(true);
            heart1.SetActive(true);
            heart2.SetActive(true);
            Vector3 start = new Vector3(x, y, 0);
        Quaternion startr = new Quaternion (0, 0, 0, 0);
        player.SetActive(false);
        t.SetPositionAndRotation(start, startr);
        player.SetActive(true);
        }
    }

    public void LateUpdate()
    {
        if (shoot.fire == false)
        {
            bool jump = false;
            Vector2 up = new Vector2(0, jumpin);

            jump = Input.GetKeyDown(KeyCode.Space);

            if (jump == true)
            {
                t.Translate(up);
            }
        }
    }
}