﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_View : MonoBehaviour {

    public GameObject Main;
    private Vector3 diff;

    void Start()
    {
        diff = transform.position - Main.transform.position;
    }

    void LateUpdate()
    {
        transform.position = Main.transform.position + diff;
    }
}
