﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shoot : MonoBehaviour {

    private Rigidbody2D rb2d;
    public float speed;
    public GameObject bullet;
    private Transform t;
    public bool fire;
    private float x;
    private float y;
    public GameObject main;
    public Move move;
    private float revspeed;
    public int enemys;
    public int bosss;
    public int mbosss;
    public NPC boss;
    public NPC mboss;
    public NPC enemy;
    Vector2 pos;

    void Start () {

        rb2d = GetComponent<Rigidbody2D>();
        t = GetComponent<Transform>();
        rb2d.simulated = false;
        fire = false;
        x = t.localPosition.x;
        y = t.localPosition.y;
    }

    private void LateUpdate()
    {
        if (fire == false)
        { fire = Input.GetKeyDown(KeyCode.C);

            if (fire == true)
            {

                if (move.right == true)
                {
                    x = t.localPosition.x;
                    y = t.localPosition.y;
                    rb2d.simulated = true;
                    Vector2 fir = new Vector2(speed, 0);
                    rb2d.AddForce(fir);
                }

                else
                {
                    x = t.localPosition.x;
                    y = t.localPosition.y;
                    rb2d.simulated = true;
                    Vector2 fir = new Vector2(speed, 0);
                    rb2d.AddForce(fir * -1);
                }
            }
        }
    }

     private void OnTriggerEnter2D(Collider2D other)
    {
        pos = new Vector2(x, y);
            if (other.gameObject.CompareTag("Enemy"))
            {
                revspeed = speed * -1;
                Vector2 revfire = new Vector2(revspeed, 0);
                rb2d.AddForce(revfire);
                bullet.SetActive(false);
                t.localPosition = pos;
                bullet.SetActive(true);
                enemy.Enemyhealth(other.gameObject);
                rb2d.simulated = false;
                fire = false;
            }

            if (other.gameObject.CompareTag("Boss"))
            {
                revspeed = speed * -1;
                Vector2 revfire = new Vector2(revspeed, 0);
                rb2d.AddForce(revfire);
                bullet.SetActive(false);
                t.localPosition = pos;
                bullet.SetActive(true);
                boss.Bosshealth(other.gameObject);
                rb2d.simulated = false;
                fire = false;
            }

            if (other.gameObject.CompareTag("M-Boss"))
            {
                revspeed = speed * -1;
                Vector2 revfire = new Vector2(revspeed, 0);
                rb2d.AddForce(revfire);
                bullet.SetActive(false);
                t.localPosition = pos;
                bullet.SetActive(true);
                mboss.mbosshealth(other.gameObject);
                rb2d.simulated = false;
                fire = false;
            }

        else
        {
            t.localPosition = pos;
            rb2d.simulated = false;
            fire = false;
            revspeed = speed * -1;
            Vector2 revfire = new Vector2(revspeed, 0);
            rb2d.AddForce(revfire);
        }
    }

    public void Update()
    {
        if (move.pos == true)
        {
            bosss = 50;
            enemys = 5;
            mbosss = 25;
        }
    }
}
