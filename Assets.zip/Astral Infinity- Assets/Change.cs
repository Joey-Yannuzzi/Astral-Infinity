﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Change : MonoBehaviour {

    public Move move;
    public int worldnum;
	void Start () {
		
	}

    private void Update()
    {
        if (move.world == true)
        {
            SceneManager.LoadScene(sceneBuildIndex: worldnum + 1);
        }
    }
}
